package pl.maro_projekt.maro_quiz;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaroQuizApplicationTests {

	@Test
	void contextLoads() {
	}

}
