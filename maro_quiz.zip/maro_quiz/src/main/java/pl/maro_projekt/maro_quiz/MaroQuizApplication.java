package pl.maro_projekt.maro_quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaroQuizApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaroQuizApplication.class, args);
	}

}
